﻿internal class Program
{
    private static void Main(string[] args)
    {
        String[] frutas = new String[5] { "Manzana", "Banana", "Naranja", "Pera", "Uva" };
        foreach(String fruta in frutas)
        {
        Console.WriteLine("Hello, World!");
        }
    }
}