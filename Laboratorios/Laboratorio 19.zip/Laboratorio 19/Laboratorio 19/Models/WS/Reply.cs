﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Laboratorio_19.Models.WS
{
    public class Reply
    {
        public int result { get; set; }
        public string message { get; set; }
    }
}