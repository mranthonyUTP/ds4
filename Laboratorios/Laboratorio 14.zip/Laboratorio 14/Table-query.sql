CREATE TABLE Productos(
	ID		INT UNIQUE,
	Nombre	VARCHAR(25),
	Precio	FLOAT(2),
	Stock	INT
);