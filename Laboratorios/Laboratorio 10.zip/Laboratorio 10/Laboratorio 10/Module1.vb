﻿Module Module1

    Sub Main()
        Console.WriteLine("Hola este es un programa de consola")
        Console.WriteLine("SI")
    End Sub

End Module
