﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Laboratorio 10")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("GamerS")>
<Assembly: AssemblyProduct("Laboratorio 10")>
<Assembly: AssemblyCopyright("Copyright © GamerS 2025")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("d54f5aae-cd04-45f4-9a7c-0fab4936bbf6")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version
'      Build Number
'      Revision
'

<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>
