﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Laboratorio103")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("GamerS")>
<Assembly: AssemblyProduct("Laboratorio103")>
<Assembly: AssemblyCopyright("Copyright © GamerS 2025")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("0e4a03ff-7639-4e0b-a3a5-8578b4e5d6b2")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version
'      Build Number
'      Revision
'

<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>
